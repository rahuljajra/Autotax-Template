$(document).ready(function(){
    $('.navbar-dark.bg-white li.nav-item').click(function(){
        $('.navbar-dark.bg-white li.nav-item').removeClass('active');
        $(this).addClass('active');
    });
    $('#hamburger').on('click', function () {
        $(this).toggleClass('active');
        $('ul#navbar-toggle').toggle();
    });
});